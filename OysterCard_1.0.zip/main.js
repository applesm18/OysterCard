/*
The Oyster Card Problem
This is made by msapple0338@gmail.com for the test of tech with london bus card problem.

Everystation has their price of take up a bus and their price is not constant.
Also Everystaton has their fee is that means the fee of passin bus.
maxfee is the baned price that is applyed anyone who dosen't swipe off.
var stations = [
    {x: 0.2, y: 0.78, name: 'Holborn', price: 2.5, fee: 0.5, max: 3.20},
    {x: -0.6, y: 0.46, name: 'Earl’s Court', price: 2.0, fee: 0.25, max: 3.20},
    {x: -1.2, y: -0.02, name: 'Wimbledon', price: 2.0, fee: 0.25, max: 3.20},
    {x: -1.0, y: -0.76, name: 'Hammersmith', price: 2.0, fee: 0.25, max: 3.20}
];

those x, y of stations is the position of station in the londonmap.

if you click the station first then you take up the bus, after you click the station secondly you will take off the bus, finally you can show the total fare.

if you click the button of swipe off, additional penalties will apply to you  with max price
*/


import * as THREE from 'three';
import { TextGeometry } from 'three/examples/jsm/geometries/TextGeometry.js';
import { FontLoader } from 'three/examples/jsm/loaders/FontLoader.js';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader";
import { DRACOLoader } from "three/examples/jsm/loaders/DRACOLoader";
import { Constraint } from 'cannon';

var maxfee = 3.20;
var stations = [
    {x: 0.2, y: 0.78, name: 'Holborn', price: 2.5, fee: 0.5, max: 3.20},
    {x: -0.6, y: 0.46, name: 'Earl’s Court', price: 2.0, fee: 0.25, max: 3.20},
    {x: -1.2, y: -0.02, name: 'Wimbledon', price: 2.0, fee: 0.25, max: 3.20},
    {x: -1.0, y: -0.76, name: 'Hammersmith', price: 2.0, fee: 0.25, max: 3.20}
];

var
    container,
    renderer,
    scene,
    camera,
    fov = 50
    ;

class LondonBus{
    constructor(model){
        this.dir = new THREE.Vector2(-1, 0);
        this.position = new THREE.Vector3(0, 0, 0);
        this.visible = false;
        this.target = new THREE.Vector3(0, 0, 0);
        this.next = new THREE.Vector3(0, 0, 0);
        this.state = "moving";
        this.speed = 0.1;
        this.interval = 200;
        this.model = model;
        this.rotatespeed = 0.1;
        this.IntervalMove = null;
        this.start = -1;
        this.end = -1;
        this.next = -1;
    }

    SetStateStay(){
        this.state = "stay";
    }

    SetStateMoving(){
        this.state = "moving";
    }

    SetStateRotating(){
        this.state = "rotating";
    }

    SetStateRotated(){
        this.state = "rotated";
    }

    SetStateArrived(){
        this.state = "arrived";
    }

    SetStateStartup(){
        this.state = "startup";
    }

    IsStay(){
        return this.state == "stay";
    }

    IsMoving(){
        return this.state == "moving";
    }

    IsRotated(){
        return this.state == "rotated";
    }
    IsRotating(){
        return this.state == "rotating";
    }

    IsArrived(){
        return this.state == "arrived";
    }

    IsStartup(){
        return this.state == "startup";
    }

    Stay(index){
        this.SetStateStay();
        this.model.position.set(stations[index].x, stations[index].y, this.model.position.z);
        this.position = this.model.position;
        this.RotateInit();
        this.start = index;
    }

    SetTargetPosition(x, y){
        this.target.x = x;
        this.target.y = y;
    }

    Move(index){
        this.end = index;
        this.InitNextStation();
        this.SetStateStartup();
        // this.SetTargetPosition(stations[index].x, stations[index].y);
        this.IntervalMove = setInterval(()=>{this.OnMoving(this)}, this.interval);
    }

    OnMoving(self){
        if(self.IsStartup())
        {
            self.RotateTarget();
        }
        else if(self.IsRotating())
        {
            self.RotateTarget();
        }
        else if(self.IsRotated())
        {
            self.RunningTarget();
        }
        else if(self.IsArrived())
        {
            self.ArrivedTarget();
        }        
    }


    InitNextStation()
    {
        if(this.start < this.end)
        {
            this.next = this.start + 1;
        }
        else{
            this.next = this.start - 1;
        }

        this.SetTargetPosition(stations[this.next].x, stations[this.next].y);
    }

    SelectNextStation()
    {
        if(this.start < this.end)
        {
            this.next++;
        }
        else{
            this.next--;
        }
        this.SetTargetPosition(stations[this.next].x, stations[this.next].y);
    }
    

    ArrivedTarget()
    {
        Arrived();
        if(this.IntervalMove)
        {
            clearInterval(this.IntervalMove);
            console.log("Arrived Clear Interval");
        }
    }

    IsEndStation()
    {
        return this.end == this.next;
    }

    RunningTarget()
    {
        if(this.IsArriveNext())
        {            
            if(this.IsEndStation())
            {
                this.SetStateArrived();
            }
            else{
                this.SelectNextStation();
                this.SetStateStartup();
            }            
        }
        else{
            var direction = new THREE.Vector3();
            direction.subVectors( this.target, this.position ).normalize();

            direction.x = direction.x * this.speed;
            direction.y = direction.y * this.speed;
            this.position.x += direction.x;
            this.position.y += direction.y;
            // console.log("running positon = > ", direction, this.model.position);
        }
    }

    RotateInit(){
        console.log("rotaton init");
    }

    RotateTarget(){
        
        if(!this.IsRotateTarget())
        {
            this.model.rotateY(this.rotatespeed);
        }
        else{
            this.SetStateRotated();
        }
    }

    IsRotateTarget(){
        var direction = new THREE.Vector3();
        direction.subVectors( this.target, this.position ).normalize();
        // console.log("this.model.getWorldDirection = ,", direction, this.model.rotation);

        if(this.model.rotation._x < 0 && direction.x > 0 || this.model.rotation._x > 0 && direction.x < 0)
        {
            if(Math.abs(direction.y + this.model.rotation._y) < this.rotatespeed * 1.5) return true;
        }
        else{
            if(Math.abs(direction.y - this.model.rotation._y) < this.rotatespeed * 1.5) return true;
        }

        return false;
    }

    Distance(a, b){
        return Math.sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
    }

    IsArriveTarget()
    {
        if(this.Distance(this.position, this.target)< this.speed * 1.5) return true;
        return false;
    }

    IsArriveNext()
    {
        if(this.Distance(this.position, stations[this.next])< this.speed * 1.5) return true;
        return false;
    }


    OnUpdate(){

    }
}

    
var takebus = 0;
var width  = window.innerWidth;
var height = window.innerHeight;
var objects = [];
    container = document.getElementById( "container" );

    var pointer = new THREE.Vector2();
    var raycaster = new THREE.Raycaster();  

    scene = new THREE.Scene();

    camera = new THREE.PerspectiveCamera(
        fov,
        window.innerWidth / window.innerHeight,
        1,
        10000 );
    camera.position.set(0, 0, 2.0);

    // var mat_ground = new THREE.MeshPhongMaterial( { ambient: 0x05055, color: 0x00FFF0, specular: 0xababab, shininess: 50 } );
    // var mat_txt = new THREE.MeshPhongMaterial( { ambient: 0x05055, color: 0xFF0F, specular: 0xababab, shininess: 50 } );

    scene.add(new THREE.AxesHelper(100000));
    var light = new THREE.DirectionalLight( 0xFFFFFFFF);
    light.intensity = 1.0;
    light.position.set( 1.0, 1.0, 6.0 ).normalize();
    scene.add(light);

    var textureLoader = new THREE.TextureLoader();
    var texture = textureLoader.load("./public/map/london-map.png");
    var ground = new THREE.Mesh(
        new THREE.BoxGeometry( 2.0*(window.innerWidth/window.innerHeight), 2.0, 0.01),
        new THREE.MeshBasicMaterial( { map: texture } )
    );
    ground.position.set(0, 0, 0);
    scene.add( ground );

    const dracoLoader = new DRACOLoader();
    dracoLoader.setDecoderPath( 'three/examples/jsm/libs/draco/gltf/' );

    const GLTloader = new GLTFLoader();
    GLTloader.setDRACOLoader( dracoLoader );
    
    function AsyncLoader(mloader,url) {
        return new Promise((resolve, reject) => {
            mloader.load(url, (data) => resolve(data), null, reject);
        });
    }

    const busstop = await AsyncLoader(GLTloader , 'public/models/busstop.glb');
    const bus = await AsyncLoader(GLTloader , 'public/models/bus.glb');
    const model_bus = bus.scene.clone();

    AddBus(new THREE.Vector3(0.0, 0.0, 0.0), "bus");

    var _londonBus = new LondonBus(model_bus);

    function AddBus(pos, name)
    {        
        model_bus.position.set( pos.x + 0.15, pos.y + 0.15, 0.05);
        model_bus.scale.set( 0.05, 0.05, 0.05 );
        model_bus.rotateY(-Math.PI*3.0/2.0);
        model_bus.rotateZ(-Math.PI*3.0/2.0);
        model_bus.rotateY(Math.PI/2.0);
        // model.rotateY(0.8);

        model_bus.name = name;
        scene.add( model_bus );
    }

    
    
    function AddBusStop(pos, name)
    {
        const model = busstop.scene.clone();
        model.position.set( pos.x-0.05, pos.y, pos.z + 0.1);
        model.scale.set( 0.01, 0.02, 0.02 );
        model.rotateX(0.2);
        // model.rotateY(0.8);

        model.name = name;
        scene.add( model );
        
        objects.push(model);
    }

    const loader = new FontLoader();
    const font = await AsyncLoader(loader, 'public/fonts/helvetiker_bold.typeface.json');
    const fontsize = 0.08;
    stations.forEach( position => {
        var mat_station = new THREE.MeshPhongMaterial( { ambient: 0x05055, color: 0xFF0F, specular: 0xababab, shininess: 50 } );

        var station = new THREE.Mesh(
            new THREE.SphereGeometry(0.05, 100),
            mat_station
        );
        station.position.set(position.x, position.y, 0.01);
        station.name = position.name;
        scene.add( station );
        objects.push(station);
        // AddBusStop(new Vec3(position.x, position.y, 0.1), position.name);

        const textGeometry = new TextGeometry( position.name, {
            font: font,
            size: fontsize,
            height: 0.005,
            curveSegments: 20,
            bevelEnabled: true,
            bevelThickness: fontsize*.5,
            bevelSize: fontsize/10.0,
            bevelOffset: 0.0,
            bevelSegments: 20
          } );

        var mat_txt = new THREE.MeshPhongMaterial( { ambient: 0x05055, color: 0xFF0F, specular: 0xababab, shininess: 50 } );
        var title = new THREE.Mesh( textGeometry, mat_txt);
        title.position.set(position.x, position.y, 0.01);
        title.name = position.name;
        scene.add( title );
        objects.push(title);
        // scene.add( station );
    });
    
    var mat_station = new THREE.MeshPhongMaterial( { ambient: 0x05055, color: 0xFF0F, specular: 0xababab, shininess: 50 } );

    var swipeoff = new THREE.Mesh(
        new THREE.SphereGeometry(0.05, 100),
        mat_station
    );
    swipeoff.position.set(0.6, -0.8, 0.01);

    var OfftextGeometry = new TextGeometry( "Swipe OFF", {
        font: font,
        size: fontsize,
        height: 0.005,
        curveSegments: 20,
        bevelEnabled: true,
        bevelThickness: fontsize*.5,
        bevelSize: fontsize/10.0,
        bevelOffset: 0.0,
        bevelSegments: 20
      } );

    OfftextGeometry.name = "swipe";
    var mat_txt = new THREE.MeshPhongMaterial( { ambient: 0x05055, color: 0xFF0F, specular: 0xababab, shininess: 50 } );
    var swipe = new THREE.Mesh( OfftextGeometry, mat_txt);
    swipe.position.set(0.6, -0.8, 0.01);
    swipe.name = "swipe";

    swipeoff.name = "swipe";
    scene.add( swipeoff );
    objects.push(swipeoff);
    scene.add( swipe );
    objects.push(swipe);



    var FaretextGeometry = new TextGeometry( "FARE:", {
        font: font,
        size: fontsize,
        height: 0.005,
        curveSegments: 20,
        bevelEnabled: true,
        bevelThickness: fontsize*.5,
        bevelSize: fontsize/10.0,
        bevelOffset: 0.0,
        bevelSegments: 20
      } );

    FaretextGeometry.name = "FARE";
    var mat_fare = new THREE.MeshPhongMaterial( { ambient: 0x05055, color: 0xFF0F, specular: 0xababab, shininess: 50 } );
    var Fare = new THREE.Mesh( FaretextGeometry, mat_fare);
    Fare.position.set(0.0, 0.0, 0.01);
    Fare.name = "FARE";
    scene.add( Fare );

    renderer = new THREE.WebGLRenderer();
    renderer.setSize( window.innerWidth, window.innerHeight );
    renderer.setPixelRatio( window.devicePixelRatio );

    container.appendChild( renderer.domElement );

    // var controls = new OrbitControls( camera, renderer.domElement );

    onWindowResize();
    window.addEventListener( 'resize', onWindowResize );

    render();


document.addEventListener( 'resize', onWindowResize );

window.addEventListener( 'pointerdown', onPointerDown );



function onWindowResize () {

	renderer.setSize( window.innerWidth, window.innerHeight );
	camera.aspect = window.innerWidth / window.innerHeight;
	camera.updateProjectionMatrix();

}

function SelectColor(object){
    if(object.material === undefined) return;
    object.material.color = new THREE.Color(0, 150, 100);
}

function ClearColor(object){
    if(object.material === undefined) return;
    object.material.color.setHex(0xFF0F);
}

function onPointerDown( event ) {

	// calculate pointer position in normalized device coordinates
	// (-1 to +1) for both components

	pointer.x = ( event.clientX / width ) * 2 - 1;
	pointer.y = - ( event.clientY / height ) * 2 + 1;

  console.log("pointer = ", pointer);

  raycaster.setFromCamera(pointer, camera);
  var intersects = raycaster.intersectObjects(scene.children, true);
  
  for (var i = 0; i < intersects.length; i++) {
    // console.log("intersects["+i+"].object.name = ",intersects[i].object.name);
    for(var j = 0; j < stations.length; j++)
    {
        if(stations[j].name == intersects[i].object.name)
        {
            // intersects[i].object.material.color = new THREE.Color(0, 150, 100);
            // SelectColor(intersects[i].object);
            
            onClickStation(j);
            SelectObject(intersects[i].object.name);
            return;
        }
    }    

    if(intersects[i].object.name == "swipe")
    {
        if(Swipeoff()){
            SelectObject(intersects[i].object.name);    
        }
        return;
    }
  }
}

function SelectObject(name)
{
    for(var i = 0; i < objects.length; i++)
    {
        if(objects[i].name == name)
        {
            SelectColor(objects[i]);
        }
    }
}

function UnSelectObject(name)
{
    for(var i = 0; i < objects.length; i++)
    {
        if(objects[i].name == name)
        {
            ClearColor(objects[i]);
        }
    }
}

function ClearAll()
{
    for(var i = 0; i < objects.length; i++)
    {
       ClearColor(objects[i]);
    }
}

function StartupBus(index)
{
    _londonBus.Stay(index);
}

function Arrived()
{
    var price = calculateFare();
    DrawFare(price);
}

function MoveBus(index)
{
    end = index;
    console.log("MoveBus=====this,", this);
    _londonBus.Move(
        index
    );
}

var start = -1;
var end = -1;

function onClickStation(index){
    console.log("===>", index);
    if(takebus == 0)
    {
        ClearFare();
        start = index;
        StartupBus(index);
    }
    else{
        // end = index;
        // var price = calculateFare();
        // DrawFare(price);

        MoveBus(index);
    }
    takebus++;
    takebus = takebus % 2;
}

function calculateFare()
{
    // if(start > end) start += stations.length;
    length = Math.abs(end - start);
    if(length == 0)
    {
        return 0.0;
    }

    if(length < 2)
    {
        if(start == 0 || end == 0) return stations[0].fee + stations[0].price;

        return stations[end%stations.length].fee + stations[start%stations.length].price;
    }
    else{
        return maxfee;
    }
}

function Swipeoff(){
    if(takebus == 1)
    {
        takebus = 0;
        start = -1;
        end = -1;
        DrawFare(3.20);
        return 1;
    }

    return 0;
}

function ClearFare()
{
    ClearAll();

    console.log("ClearFare");
    Fare.visible = false;
    scene.remove(FaretextGeometry.name);
    scene.remove(Fare.name);

    FaretextGeometry = new TextGeometry( "FARE: ", {
        font: font,
        size: fontsize,
        height: 0.005,
        curveSegments: 20,
        bevelEnabled: true,
        bevelThickness: fontsize*.5,
        bevelSize: fontsize/10.0,
        bevelOffset: 0.0,
        bevelSegments: 20
      } );

    Fare = new THREE.Mesh( FaretextGeometry, mat_fare);
    Fare.position.set(0.0, 0.0, 0.01);
    Fare.visible = true;

    scene.add(Fare);
    
}

function DrawFare(price)
{
    FaretextGeometry = new TextGeometry( "FARE: " + price.toString(), {
        font: font,
        size: fontsize,
        height: 0.005,
        curveSegments: 20,
        bevelEnabled: true,
        bevelThickness: fontsize*.5,
        bevelSize: fontsize/10.0,
        bevelOffset: 0.0,
        bevelSegments: 20
      } );

    Fare = new THREE.Mesh( FaretextGeometry, mat_fare);
    Fare.position.set(0.0, 0.0, 0.01);
    Fare.visible = true;

    scene.add(Fare);
}

function render() {
    renderer.render( scene, camera );
    requestAnimationFrame( render );
}
